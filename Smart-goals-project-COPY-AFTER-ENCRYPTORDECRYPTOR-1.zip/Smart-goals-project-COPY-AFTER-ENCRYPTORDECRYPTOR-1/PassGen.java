 import java.lang.Math;
import java.security.NoSuchAlgorithmException;  
import java.security.MessageDigest; 

class PassGen {
public static String password = "";

  //Charset, special charset, numset;
  private static String lowerCharset = "abcdefghijklmnopqrstuvwxyz";
  private static String upperCharset="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  private static String numberChars="012345689";
  private static String specialChars="!@#$%^&*()_-+?><{}";

  private static String[] charSets = {lowerCharset, upperCharset, numberChars, specialChars};


  public static String generate(int length, boolean upperCase, boolean ifNumbers, boolean specialChars) {
    
    String currentCharSet = "";
    for (int x =  0; x <length; x++) {
      char randChar;
      int charSpec;
      if(specialChars&&ifNumbers&&upperCase) {
        charSpec=(int)(Math.random()*4); 
        currentCharSet=charSets[charSpec];
        
      } 
      else if(specialChars&&ifNumbers){
        charSpec=(int)(Math.random()*3);
        // charspec==1==ifNumbers==true 
        if(charSpec==1)
            currentCharSet=charSets[2];
        // charspec==2==specialChars==true 
        else if(charSpec==2)
            currentCharSet=charSets[3];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      }
      else if(specialChars&&upperCase) {
        charSpec=(int)(Math.random()*3);
        // charspec==1==upperCase==true
        if(charSpec==1)
            currentCharSet=charSets[1];
        // charspec==2==specialChars==true
        else if(charSpec==2)
            currentCharSet=charSets[3];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      
      }
      else if(ifNumbers&&upperCase) {
        charSpec=(int)(Math.random()*3);
        // charspec==1==upperCase==true
        if(charSpec==1)
            currentCharSet=charSets[1];
        // charspec==1==upperCase==true
        else if(charSpec==2)
            currentCharSet=charSets[2];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      }
      else if(upperCase) {
      charSpec=(int)(Math.random()*2);
        // charspec==1==upperCase==true
        if(charSpec==1)
            currentCharSet=charSets[1];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      }
      else if(ifNumbers) {
      charSpec=(int)(Math.random()*2);
        // charspec==1==upperCase==true
        if(charSpec==1)
            currentCharSet=charSets[2];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      }
      else if(specialChars) {
      charSpec=(int)(Math.random()*2);
        // charspec==1==specialChars==true
        if(charSpec==1)
            currentCharSet=charSets[3];
        // charspec==0==lowercase
        else 
            currentCharSet=charSets[0];
      }
      else
        currentCharSet=charSets[0];
      randChar=currentCharSet.charAt((int)(Math.random()*currentCharSet.length()));
      password = password + randChar; 
    }
    return password;
  }


  
//////ENCRYPTION START///////
public static void encrypt()   
    {  
        /* Plain-text password initialization. */  
        String encryptedpassword = null;  
        try   
        {  
            /* MessageDigest instance for MD5. */  
            MessageDigest m = MessageDigest.getInstance("MD5");  
              
            /* Add plain-text password bytes to digest using MD5 update() method. */  
            m.update(password.getBytes());  
              
            /* Convert the hash value into bytes */   
            byte[] bytes = m.digest();  
              
            /* The bytes array has bytes in decimal form. Converting it into hexadecimal format. */  
            StringBuilder s = new StringBuilder();  
            for(int i=0; i< bytes.length ;i++)  
            {  
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }  
              
            /* Complete hashed password in hexadecimal format */  
            encryptedpassword = s.toString();  
        }   
        catch (NoSuchAlgorithmException e)   
        {  
            e.printStackTrace();  
        }  
          
        /* Display the unencrypted and encrypted passwords. */  
        System.out.println("Plain-text password: " + password);  
        System.out.println("Encrypted password using MD5: " + encryptedpassword);  
    }  


//////ENCRYPTION END///////
  
}