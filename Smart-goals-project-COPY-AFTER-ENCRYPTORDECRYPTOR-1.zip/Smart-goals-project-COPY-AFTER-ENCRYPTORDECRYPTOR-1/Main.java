import java.io.FileWriter; // Import the FileWriter class
import java.io.File;
import java.io.IOException;

class Main {
  public static void main(String[] args) {
   try{
		File Cfile = new File("Passwords.txt");
		Cfile.createNewFile();
		 FileWriter Wfile = new FileWriter("Passwords.txt");
		// passgen tesing.
		webpass credentials=new webpass("cactusdrinking","moon_fricker422","apple");
  webpass.addNewPassword(Wfile,credentials);
		Wfile.close();
		 String pass = PassGen.generate(10, true, true, true);
    // System.out.println(pass);

     String proPass = "";
     for(int i = 0;i<pass.length();i++){///maing program password in main
      proPass = proPass + i;
     }
		
    Encryptor enc = new Encryptor();
    String enc_pass = enc.encrypt(pass, proPass);
    String dec = enc.decrypt(enc_pass, proPass);
	}
   

		 catch (IOException e) {
  	System.out.println("An error occurred.");
     e.printStackTrace();
    }
		
		//Cfile.delete();
  
}
}