import java.io.*;

public class Encryptor {

  
  
  /* Driver Code */
  public static String encrypt(String plainText, String programPassword) {
    /* Plain-text password initialization. */
    // password2 = programmed password = the key to password
    String password = plainText;
    String password2 = programPassword;
    
    int[] decryptedPassword = null;
    decryptedPassword = new int[password.length()];
    
    int[] encryptedPassword = null;
    encryptedPassword = new int[password.length()];

    String encryptedPass = "";
    

    System.out.println("Password: " + password);// printing both passwords
    System.out.println("Programed Password: " + password2);

    System.out.println("");// space

    byte[] ProByteArray = password2.getBytes();// initializing passwords into bytes
    byte[] PassByteArray = password.getBytes();

    System.out.println("Password In Byte Form: ");/// printing password's bytes

    for (int i = 0; i < PassByteArray.length; i++) {

      System.out.print(PassByteArray[i] + " ");

    }

    System.out.println("");// space

    System.out.println("Programmed Password In Byte Form: ");/// printing programmed password's bytes

    for (int i = 0; i < ProByteArray.length; i++) {
      
      System.out.print(ProByteArray[i] + " ");
      
    }

    System.out.println("");// space
    System.out.println("");// space

    System.out.println("Password & Programmed Password Multiplied from Bytes: ");// printing programmed password and
                                                                                 // password's byte product

    for (int i = 0; i < PassByteArray.length; i++) {/// encryptor

      encryptedPassword[i] = PassByteArray[i] * ProByteArray[i];
      encryptedPass = encryptedPass + encryptedPassword[i] + " ";

    }

    System.out.println(encryptedPass);
    return encryptedPass;
  }


////STRING TO INTEGER ARRAY METHOD
static int[] method(String str)
    {
 
        String[] splitArray = str.split(" ");
        int[] array = new int[splitArray.length];
 
        // parsing the String argument as a signed decimal
        // integer object and storing that integer into the
        // array
        for (int i = 0; i < splitArray.length; i++) {
            array[i] = Integer.parseInt(splitArray[i]);
        }
        return array;

    }



  

//////DECRYPTION

public static String decrypt(String encryptedPassword, String programPassword) {
   
    System.out.println("");//space
    System.out.println("");//space

    String password2 = programPassword;
    int[] encryptedPasswordArray = null;
    encryptedPasswordArray = new int[password2.length()];
    int[] decryptedPasswordArray = null;
    decryptedPasswordArray = new int[password2.length()];
    String decryptedPass = "";


    byte[] ProByteArray = password2.getBytes();// initializing passwords into bytes
 
   
    System.out.println("Encrypted Password & Programmed Password Divided From Bytes: ");
   ///  printing programmed password and

   // Bufferedreader declaration
        BufferedReader br = new BufferedReader(
            new InputStreamReader(System.in));
 
        // string declaration
        String str = encryptedPassword;
        int i;
 
        // declaring the variable & calling the method with
        // passing string as an argument
        encryptedPasswordArray = method(str);
 
        // decrypting the Integer array
        for (i = 0; i < encryptedPasswordArray.length; i++) {
          decryptedPasswordArray[i] = encryptedPasswordArray[i] / ProByteArray[i];
          System.out.print(decryptedPasswordArray[i] + " ");
        }
 
    
    System.out.println("");//space
    System.out.println("");//space
    System.out.println("Password From Decryption: ");
    
    for(i = 0;i<decryptedPasswordArray.length;i++){///converts int array into a string

    
    decryptedPass = decryptedPass + (char)decryptedPasswordArray[i] + "";
      
    }
    System.out.println(decryptedPass);//prints password in plain text
    return decryptedPass;///outputs decrypted password in plain text
 }
  
  
}