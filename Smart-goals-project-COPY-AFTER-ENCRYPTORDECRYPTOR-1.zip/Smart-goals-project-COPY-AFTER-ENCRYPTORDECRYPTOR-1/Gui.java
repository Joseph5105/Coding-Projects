import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import  javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class Gui{
  private static JFrame homeFrame;
  private static JPanel homePanel;
  
  
  
  public static void main(String[] args) {
    System.out.println("GUI entered main class");
    JPanel homePanel = new JPanel();
    JFrame homeFrame = new JFrame();
    homeFrame.setSize(300,150);
    homeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    homeFrame.add(homePanel);
    homePanel.setLayout(null);

    homeFrame.setVisible(true);
    
    
  
  }
}