import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors
public class webpass{
	String webName;
	String userName;
	String passWord;
	public webpass(final String webName, final String userName, final String passWord){
		this.webName=webName;
		this.userName=userName;
		this.passWord=passWord;
	}

	public void setWebName(final String webName){
		this.webName=webName;
	}
	public void setUserName(final String userName){
		this.userName=userName;
	}
	public void setPassword(final String passWord){
		this.passWord=passWord;
	}
	public String getWebName(){
		return webName;
	}
	public String getUserName(){
		return userName;
	}
	public String getPassWord(){
		return passWord;
	}
 public static void addNewPassword(final FileWriter file,webpass password){
	try{	
	 final String credit="\n"+password.getWebName()+" "+password.getUserName()+" "+password.getPassWord();
	 file.write(credit);
	} catch (final IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
 }
 }}
	
	
	
