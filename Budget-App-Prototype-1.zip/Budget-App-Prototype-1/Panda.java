import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

public class Panda {

  static Scanner scanner = new Scanner(System.in);
  
  static String bold = "\u001B[1m";
  static String reset = "\u001B[0m";
  static String filePath = "data.csv";// Storing File Path
  
  public static void spendingMenu() {

    try{

      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader

      String line1;// Initializing Line1 Variable (The Amount of Percetage Left to Add to Budget)
      String line2;// Initializing Line2 Variable (All Expenses & Percentages)
      String line3;// Initializing Line3 Variable (Monthly Income & Amount that should be spent on
                   // each expense)
      String line4;// Initializing Line4 Variable (Current Spending Total & Amount that has been
                   // spent on each expense)
      String line5;//Initializing Line5 Variable (User's inventory of items to use on BB)

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();// Storing the forth line into the line variable
      line5 = bufferedReader.readLine();
      

      String[] parts1 = null;// parts variables
      String[] parts2 = null;
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
      int j = 1;// second index
      
      String[] partsNum2 = line2.split(",");// Splitting the line2 into parts whenever there is a comma to separate
      String[] partsNum3 = line3.split(",");
      String[] partsNum4 = line4.split(",");
      
      int numStrings2 = partsNum2.length;// Initializing numStrings2 to be the amount of strings in each line
      int twoDivider = 1;// Initializing a divider to print in order

      bufferedReader.close();// Closes BufferedReader

      fileReader = new FileReader(filePath);// Opens new fileReader
      bufferedReader = new BufferedReader(fileReader);// Opens new bufferedReader

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Sets line to be the second line
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();// Storing the forth line into the line varible
      line5 = bufferedReader.readLine();

      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");// splitting each string by commas into the string array
      parts5 = line5.split(",");

      for(int i = 0;i<5;i++){
        System.out.println("");
      }

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁MAX SPENDINGS▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + "Monthly Income: " + parts3[0] + "$" + reset);
      System.out.println("");

      for (int i = 0; i < numStrings2; i += 2) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line
        System.out.print(parts3[j] + "$");// prints the j string of the line
        System.out.println("");

        j++;

      } // FOR END

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁CURRENT SPENDINGS▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + "Monthly Balance: " + parts4[0] + "$" + reset);
      System.out.println("");

      j = 1;// reset second index

      for (int i = 0; i < numStrings2; i += 2) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line
        System.out.print(parts4[j] + "$");// prints the j string of the line
        System.out.println("");

        j++;

      }// FOR END

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁INVENTORY▁▂▃▅▆▓▒░✩");
      System.out.println("");

      for(int i = 0;i<parts5.length;i++){
        System.out.print(parts5[i]);
        System.out.println("");
      }
      
      System.out.println("");

      bufferedReader.close();// Closes BufferedReader


      String spendingOption = "";
      
      while(!spendingOption.matches("1") || !spendingOption.matches("2")){
          try{
    
            System.out.println("");
            System.out.println("[1] Add Spending");
            System.out.println("[2] Remove Spending");
            System.out.println("[3] Play With BB!");
            System.out.println("[4] Main Menu");
            System.out.println("");
            System.out.print("Enter Option: ");
            spendingOption = scanner.nextLine();
            if(spendingOption.matches("1")){
              addSpendings();
              break;
            }
            else if(spendingOption.matches("2")){
              removeSpendings();
              break;
            }
            else if(spendingOption.matches("3")){
              playWithBB();
              break;
            }
            else if(spendingOption.matches("4")){
              Main.menu();
              break;
            }
            else{
              continue;
            }
          }catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst menu)");
            System.out.println("");
          }
          
        }


      
    }//TRY END
      
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was thrown
      
      e.printStackTrace();
      
    } // CATCH END


  }//SPENDING MENU END













  

  public static void addSpendings(){//TODO
    try{
      
      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader
        
      String line1;
      String line2;
      String line3;
      String line4;
      String line5;
  
      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
        
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
    
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");
  
      String spendingName = "";
      String spendingAmount = "";
      double currSpendings = Double.parseDouble(parts4[0]);
      boolean Data = false;
      double spendingAmountNum = 0.0;
  
      while(!Data){
        try{
          System.out.print("Enter Spending Name: ");
          spendingName = scanner.nextLine();
          for(int i = 0;i<parts2.length;i++){
            if(spendingName.equals(parts2[i])){
              System.out.print("Enter Spending Amount: ");
              spendingAmount = scanner.nextLine();
              spendingAmountNum = Double.parseDouble(spendingAmount);
              Data = true;
            }
            else{
              continue;
            }
          }
        }
        catch(NumberFormatException e){
          System.out.println("");
          System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst adding spendings)");
          System.out.println("");
        }
      }


      currSpendings -= spendingAmountNum;

      String currSpendingsStr = Double.toString(currSpendings);
      String spendingsAmountStr = "";
      String newSpendingData4 = currSpendingsStr;
      long currentTimeMillis = System.currentTimeMillis();
      Random random = new Random(currentTimeMillis);
      int randNum = 0;
      int j = 1;
      
      for (int i = 0; i < parts2.length; i += 2) {// For loop in each line depending on the amount of strings

        if(spendingName.equals(parts2[i])){
          double spendingAmountD = Double.parseDouble(parts4[j]);
          double maxSpendingAmountD = Double.parseDouble(parts3[j]);
          spendingAmountD += spendingAmountNum;
          spendingsAmountStr = Double.toString(spendingAmountD);
          parts4[j] = spendingsAmountStr;
          if(spendingAmountD < maxSpendingAmountD){
            randNum = random.nextInt(100) + 1;
          }
        }
        
        j++;
        
      }

      for(int i = 1; i < parts4.length;i++){
        newSpendingData4 = newSpendingData4 + "," + parts4[i];
      }
      

      bufferedReader.close();// Closes BufferedReader
      
      System.out.println("");
      System.out.println("▓▒▒░░░Spending Added!░░░▒▒▓█");


      String itemAdded = ""; 
      String newLine5 = line5;

      if(randNum >= 0){
        if(randNum <= 91){
          System.out.println("");
          System.out.println("");
          System.out.println(bold + "🎋 ~BAMBOO TREAT~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Bamboo Treat";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else if(randNum <= 93){
          System.out.println("");
          System.out.println("");
          System.out.println(bold + "🧋 ~BAMBOO FLAVORED BOBA~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Bamboo Flavored Boba";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else if(randNum <= 95){
          System.out.println("");
          System.out.println("");
          System.out.println(bold + "⚽ ~SOCCER BALL~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Soccer Ball";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else if(randNum <= 97){
          System.out.println("");
          System.out.println("");
          System.out.println(bold + "🛝 ~A SLIDE SET~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Slide Set";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else if(randNum <= 99){
          System.out.println("");
          System.out.println("");
          System.out.println(bold + "🍧 ~BAMBOO FLAVORED SHAVED ICE~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Bamboo Flavored Shaved Ice";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else if(randNum == 100){
          System.out.println("");
          System.out.println(bold + "LEGENDARY ITEM" + reset);
          System.out.println(bold + "🤖 ~PANDA HUGGER BOT 3000~ ADDED INTO YOUR INVENTORY!" + reset);
          itemAdded = "Panda Hugger Bot 3000";
          if(line5.equals("No Items,")){
            newLine5 = itemAdded + ",";
          }
          else{
            newLine5 = line5 + itemAdded + ",";
          }
        }
        else{
          newLine5 = line5;
        }
      }
      else{
        newLine5 = line5;
      }

      FileWriter fileWriter = new FileWriter(filePath);// Initializing File Reader
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);// Initializing File Buffered Reader

      //write the 5 lines back into the temp file with modified content
      bufferedWriter.write(line1);
      bufferedWriter.newLine();
      bufferedWriter.write(line2);
      bufferedWriter.newLine();
      bufferedWriter.write(line3);
      bufferedWriter.newLine();
      bufferedWriter.write(newSpendingData4 + ",");
      bufferedWriter.newLine();
      bufferedWriter.write(newLine5);

      bufferedWriter.close();// Closes BufferedReader
      
      System.out.println("");

      spendingMenu();

      
    }//TRY END 
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was thrown
      
      e.printStackTrace();
      
    } // CATCH END

  }//ADD SPENDINGS END








  

  public static void removeSpendings(){//TODO

    try{
      
      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader
        
      String line1;
      String line2;
      String line3;
      String line4;
      String line5;
  
      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
        
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
    
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");
  
      String spendingName = "";
      String spendingAmount = "";
      double currSpendings = Double.parseDouble(parts4[0]);
      boolean Data = false;
      double spendingAmountNum = 0.0;
  
      while(!Data){
        try{
          System.out.print("Enter Spending Name: ");
          spendingName = scanner.nextLine();
          for(int i = 0;i<parts2.length;i++){
            if(spendingName.equals(parts2[i])){
              System.out.print("Enter Spending Amount: ");
              spendingAmount = scanner.nextLine();
              spendingAmountNum = Double.parseDouble(spendingAmount);
              Data = true;
            }
            else{
              continue;
            }
          }
        }
        catch(NumberFormatException e){
          System.out.println("");
          System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst adding spendings)");
          System.out.println("");
        }
      }

      currSpendings += spendingAmountNum;

      String currSpendingsStr = Double.toString(currSpendings);
      String spendingsAmountStr = "";
      String newSpendingData4 = currSpendingsStr;
      int j = 1;
      
      for (int i = 0; i < parts2.length; i += 2) {// For loop in each line depending on the amount of strings

        if(spendingName.equals(parts2[i])){
          double spendingAmountD = Double.parseDouble(parts4[j]);
          spendingAmountD -= spendingAmountNum;
          spendingsAmountStr = Double.toString(spendingAmountD);
          parts4[j] = spendingsAmountStr;
        }
        
        j++;
        
      }

      for(int i = 1; i < parts4.length;i++){
        newSpendingData4 = newSpendingData4 + "," + parts4[i];
      }
      

      bufferedReader.close();// Closes BufferedReader
      fileReader.close();// Closes FileReader

      FileWriter fileWriter = new FileWriter(filePath);
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

      //write the 5 lines back into the temp file with modified content
      bufferedWriter.write(line1);
      bufferedWriter.newLine();
      bufferedWriter.write(line2);
      bufferedWriter.newLine();
      bufferedWriter.write(line3);
      bufferedWriter.newLine();
      bufferedWriter.write(newSpendingData4 + ",");
      bufferedWriter.newLine();
      bufferedWriter.write(line5);

      bufferedWriter.close();// Closes BufferedReader
      
      System.out.println("");
      System.out.println("▓▒▒░░░Spending Removed!░░░▒▒▓█");

      spendingMenu();

      
    }//TRY END 
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was thrown
      
      e.printStackTrace();
      
    } // CATCH END
    
  }//REMOVE SPENDINGS END










  

  
  public static void playWithBB(){//TODO

    System.out.println(bold + "   BB The Budget Panda   " + reset);
    System.out.println("⠀⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
    System.out.println("⠀⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
    System.out.println("⠀⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
    System.out.println("⢀⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
    System.out.println("⠀⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
    System.out.println("⠀⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀⠀     ");
    System.out.println("⠀⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
    System.out.println("⠀⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
    System.out.println("⠀⠀⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟⠿⠃⠀      ⠀");
    System.out.println("⠀⠀⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
    System.out.println("⠀⠀⠀⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀       ");

    try{

      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader

      String line1;
      String line2;
      String line3;
      String line4;
      String line5;
  
      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
        
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
    
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁INVENTORY▁▂▃▅▆▓▒░✩");
      System.out.println("");

      for(int i = 0;i<parts5.length;i++){
        System.out.print(parts5[i]);
        System.out.println("");
      }
      
      System.out.println("");

      bufferedReader.close();// Closes BufferedReader
      fileReader.close();// Closes FileReader

      String spendingOption = "";
      
      while(!spendingOption.matches("1") || !spendingOption.matches("2")){
          try{
    
            System.out.println("");
            System.out.println("[1] Use Item on BB!");
            System.out.println("[2] Spending Menu");
            System.out.println("[3] Main Menu");
            System.out.println("");
            System.out.print("Enter Option: ");
            spendingOption = scanner.nextLine();
            if(spendingOption.matches("1")){
              usingItemOnBB();
              break;
            }
            else if(spendingOption.matches("2")){
              spendingMenu();
              break;
            }
            else if(spendingOption.matches("3")){
              Main.menu();
              break;
            }
            else{
              continue;
            }
          }catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst BB menu)");
            System.out.println("");
          }
          
        }
      
    }//TRY END
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was thrown
      
      e.printStackTrace();
      
    }//CATCH END
    
  }//PLAY WITH BB END







  

  public static void usingItemOnBB(){

    try{
      
      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader

      String line1;
      String line2;
      String line3;
      String line4;
      String line5;
  
      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
        
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
    
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁INVENTORY▁▂▃▅▆▓▒░✩");
      System.out.println("");

      for(int i = 0;i<parts5.length;i++){
        System.out.print(parts5[i]);
        System.out.println("");
      }
      
      System.out.println("");

      bufferedReader.close();// Closes BufferedReader
      fileReader.close();// Closes FileReader

      String itemOption = "";
      boolean isItem = false;
      
      while(!isItem){
          try{
    
            System.out.println("");
            System.out.println("[1] Spending Menu");
            System.out.println("[2] Main Menu");
            System.out.println("");
            System.out.print("Enter Item Name: ");
            itemOption = scanner.nextLine();
            if(itemOption.matches("1")){
              spendingMenu();
              break;
            }
            else if(itemOption.matches("2")){
              Main.menu();
              break;
            }
            else if(itemOption.matches("Bamboo Treat")){
              System.out.println("⠀⠀    ⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
              System.out.println("    🎋⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
              System.out.println("⠀    ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
              System.out.println("⠀    ⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀- Yummy! *nom nom*⠀  ");
              System.out.println("⠀    ⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
              System.out.println("⠀    ⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
              System.out.println("⠀⠀    ⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟🎋⠃⠀      ⠀");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println("⠀⠀    ⠀⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀       ");
            }
            else if(itemOption.matches("Bamboo Flavored Boba")){
              System.out.println("⠀⠀    ⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
              System.out.println("    🧋⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
              System.out.println("⠀    ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
              System.out.println("⠀    ⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀- Mmmm refreshing!⠀  ");
              System.out.println("⠀    ⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
              System.out.println("⠀    ⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
              System.out.println("⠀⠀    ⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟⠃⠀      ⠀");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println("⠀⠀    ⠀⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀       ");
            }
            else if(itemOption.matches("Soccer Ball")){
              System.out.println("⠀⠀    ⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
              System.out.println("    ⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
              System.out.println("⠀    ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
              System.out.println("⠀    ⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀- Take that!⠀  ");
              System.out.println("⠀    ⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
              System.out.println("⠀    ⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
              System.out.println("⠀⠀    ⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟⠃⠀      ⠀");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println(" ⚽~   ⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀       ");
            }
            else if(itemOption.matches("Slide Set")){
              System.out.println("⠀⠀    ⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
              System.out.println("    ⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
              System.out.println("⠀    ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
              System.out.println("⠀    ⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀- bruh...that's for kids!⠀  ");
              System.out.println("⠀    ⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
              System.out.println("⠀    ⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
              System.out.println("⠀⠀    ⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟⠃⠀      ⠀");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println("       ⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀ 🛝     ");
            }
            else if(itemOption.matches("Bamboo Flavored Shaved Ice")){
              System.out.println("⠀⠀    ⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⢰⣿⡿⠗⠀⠠⠄⡀⠀⠀⠀     ⠀ ");
              System.out.println("⠀    ⠀⠀⠀⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄      ");
              System.out.println("    🍧⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃     ");
              System.out.println("⠀    ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃⠀     ");
              System.out.println("⠀    ⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀- ahh...nice and cool!⠀  ");
              System.out.println("⠀    ⠀⠀⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧⠀⠀      ⠀");
              System.out.println("⠀    ⠀⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀      ⠀");
              System.out.println("⠀⠀    ⠀⣷⣄⡀⠀⠀⠀⢀⣴⡟⠃⠀      ⠀");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println("       ⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀       ");
            }
            else if(itemOption.matches("Panda Hugger Bot 3000")){
              System.out.println("🤖🤖🤖🤖⢀⡀🤖🤖🤖🤖🤖🤖🤖🤖");
              System.out.println("🤖🤖🤖🤖⢰⣿⡿⠗⠀⠠⠄⡀🤖🤖🤖🤖🤖");
              System.out.println("🤖🤖🤖🤖⡜⠁⠀⠀⠀⠀⠀⠈⠑⢶⣶⡄🤖🤖🤖🤖");
              System.out.println("🤖🤖 ⣶⣦⣸⠀⢼⣟⡇⠀⠀⢀⣀⠀⠘⡿⠃🤖🤖🤖🤖");
              System.out.println("🤖🤖 ⢿⣿⣿⣄⠒⠀⠠⢶⡂⢫⣿⢇⢀⠃ - SO MANY HUGGING ROBOTS!! <3");
              System.out.println("⠀🤖🤖⠈⠻⣿⣿⣿⣶⣤⣀⣀⣀⣂⡠⠊⠀🤖🤖🤖🤖");
              System.out.println("🤖🤖🤖⠃⠀⠀⠉⠙⠛⠿⣿⣿⣧🤖🤖🤖🤖");
              System.out.println("🤖🤖 ⠘⡀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡇⠀🤖🤖🤖🤖🤖");
              System.out.println("🤖🤖🤖⣷⣄⡀⠀⠀⠀⢀⣴⡟⠃🤖🤖🤖🤖");
              System.out.println("⠀⠀    ⠀⢻⣿⣿⠉⠉⢹⣿⣿⠁⠀⠀⠀      ⠀");
              System.out.println("  🤖   ⠀⠉⠁⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀🤖   ");
            }
            else{
              continue;
            }
            
          }catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst BB menu)");
            System.out.println("");
          }//CATCH END




        
          
        }//WHILE END
      
    }//TRY END
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was thrown
      
      e.printStackTrace();
      
    } // CATCH END
    
  }//USING ITEM ON BB END


  

}//PANDA CLASS END
