import java.util.Scanner;

//Title: Budget App Prototype 1
//Name: Joseph Lacap
//Date: 10/28/2023
//Location: San Antonio, Texas, United States



public class Main {

  static String bold = "\u001B[1m";
  static String reset = "\u001B[0m";

  static DisplayBudget budgetDisplay = new DisplayBudget();
  static Panda BB = new Panda();
  static boolean loveStops = false;

  public static void main(String[] args) {

    menu();// (COMPLETE & ACCURATE)
    // budgetDisplay.readBudget();//(COMPLETE & ACCURATE)
    // BB.print();///(COMPLETE & ACCURATE)
    // EditIncome.EditMonthlyIncome(); (COMPLETE & ACCURATE)

  }

  public static void menu() {

    Scanner scanner = new Scanner(System.in);
    String userInput;

    System.out.println(bold);
    System.out.println("|------------------------------------|");
    System.out.println("|                                    |");
    System.out.println("|" + reset + " 🍕🍟🥪  𝓑𝓑'𝓢 𝓑𝓤𝓓𝓖𝓔𝓣𝓘𝓝𝓖 𝓐𝓟𝓟  🪀🔫🧸 " + bold + "|");
    System.out.println("|                                    |");
    System.out.println("|     [1] View Budget                |");
    System.out.println("|     [2] Edit Monthly Income        |");
    System.out.println("|     [3] Edit Monthly Expense       |");
    System.out.println("|     [4] Edit Spendings/View BB     |");
    System.out.println("|     [5] Help/Delete Budget         |");
    System.out.println("|     [6] Quit App                   |");
    System.out.println("|                                    |");
    System.out.println("|Designed & Developed by Joseph Lacap|");
    System.out.println("|------------------------------------|");
    System.out.println(reset);

    System.out.print("Enter Option: ");

    userInput = scanner.nextLine();

    if (userInput.equals("1")) {
      for (int i = 0; i < 10; i++) {
        System.out.println("");
      }
      budgetDisplay.readBudget();
    } else if (userInput.equals("2")) {

      EditIncome.EditMonthlyIncome();

    } else if (userInput.equals("3")) {

      EditExpense.expenseMenu();

    } else if (userInput.equals("4")) {//TODO FINISH ADDING/REMOVING SPENDINGS & BB

      Panda.spendingMenu();

    } else if (userInput.equals("5")) {//TODO HELP SECTION

      DeleteBudgetPlan.helpDeleteMenu();

    } else if (userInput.equals("6")) {

      System.out.println("");
      System.out.println("█▓▒▒░░░Thank you for using BB's Budgeting App!░░░▒▒▓█");
      System.out.println("");
      System.exit(0);

    } else if(userInput.equals("show me how much you love me")){

    while(!loveStops){
    System.out.println("I love you this much <3");
    }
      
    } else {
      System.out.println("");
      System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀");
      menu();
    }

  }

}