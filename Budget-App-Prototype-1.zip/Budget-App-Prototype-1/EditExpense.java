import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EditExpense {

  static Scanner scanner = new Scanner(System.in);
  
  static String bold = "\u001B[1m";
  static String reset = "\u001B[0m";
  static String filePath = "data.csv";// Storing File Path

  
  public static void expenseMenu() {

    try {

      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader

      String line1;
      String line2;
      String line3;
      String line4;

      String[] parts1 = null;// parts variables
      String[] parts2 = null;
      String[] parts3 = null;
      String[] parts4 = null;

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();

      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");

      int numStrings2 = parts2.length;// Initializing numStrings2 to be the amount of strings in each line
      int twoDivider = 1;// Initializing a divider to print in order

      bufferedReader.close();// Closes BufferedReader

      fileReader = new FileReader(filePath);// Opens new fileReader
      bufferedReader = new BufferedReader(fileReader);// Opens new bufferedReader

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Sets line to be the second line
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();

      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");

      for(int i = 0;i<5;i++){
        System.out.println("");
      }
      
      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁EXPENSES▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + parts1[0] + "%/100%" + reset);
      System.out.println("");
      for (int i = 0; i < numStrings2; i++) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line

        if (twoDivider % 2 == 0) {// if the divider is even then a new line will separate the next amount of
                                  // strings
          System.out.println("");
          
        }

        twoDivider++;// updates the divider

      } // FOR END

      System.out.println("");


      String expenseOption = "";
      
      while(!expenseOption.matches("1") || !expenseOption.matches("2")){
          try{
    
            System.out.println("");
            System.out.println("[1] Add Expense");
            System.out.println("[2] Remove Expense");
            System.out.println("[3] Main Menu");
            System.out.println("");
            System.out.print("Enter Option: ");
            expenseOption = scanner.nextLine();
            if(expenseOption.matches("1")){
              if(parts1[0].matches("0")){
                System.out.println("");
                System.out.println("▀▄▀▄▀▄Your Expenses Have Already Been Filled!▄▀▄▀▄▀");
                continue;
              }
              addExpense();
              break;
            }
            else if(expenseOption.matches("2")){
              removeExpense();
              break;
            }
            else if(expenseOption.matches("3")){
              Main.menu();
              break;
            }
            else{
              continue;
            }
          }catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst menu)");
            System.out.println("");
          }
          
        }
      
      

    } catch (IOException e) {// In case of IOException this will provide where and why the Exception was
                           // thrown
      e.printStackTrace();

    } // CATCH END

  }//EXPENSE MENU END





  

  public static void addExpense(){
    try{

      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader
      
      String line1;
      String line2;
      String line3;
      String line4;
      String line5;

      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
      
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
  
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");

      String expenseName = "";
      String expenseAmount = "";
      int currPercent = Integer.parseInt(parts1[0]);
      boolean validAmount = false;
      int expenseAmountNum = 0;

      while(!validAmount){
        try{
          System.out.print("Enter Expense Name: ");
          expenseName = scanner.nextLine();
          System.out.print("Enter Expense Amount (" + parts1[0] + "%/100%): ");
          expenseAmount = scanner.nextLine();
          expenseAmountNum = Integer.parseInt(expenseAmount);
          if(expenseAmountNum <= currPercent){
            validAmount = true;
          }
          else{
            continue;
          }
        }
        catch(NumberFormatException e){
          System.out.println("");
          System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst expenses)");
          System.out.println("");
        }
      }

      String newExpenseData2 = "";
      String newExpenseData3 = "";
      String newExpenseData4 = "";


      int newExpenseData1Num = currPercent - expenseAmountNum;
      String newExpenseData1 = Integer.toString(newExpenseData1Num);
      

      if(line2.equals("No Data,0%,")){
        newExpenseData2 = expenseName + "," + expenseAmount + "%,";
      }
      else{
        newExpenseData2 = line2 + expenseName + "," + expenseAmount + "%,";
      }

      double incomeNum = Double.parseDouble(parts3[0]);
      int incomeNumInt = Integer.parseInt(parts3[0]);
      double trueIncomePercent1 = expenseAmountNum/100.0;
      double trueIncomePercent = trueIncomePercent1 * incomeNum;
      String IncomePercent = String.valueOf(trueIncomePercent);
      
      
      if(line3.equals(parts3[0] + ",0.00,") && incomeNumInt != 0){//line 3 changes if its the first expense
        newExpenseData3 = parts3[0] + "," + IncomePercent + ",";
      }
      else if(line3.equals(parts3[0] + ",0.00,") && incomeNumInt == 0){
        newExpenseData3 = parts3[0] + "," + IncomePercent + ",";
      }
      else if(incomeNumInt != 0){
        newExpenseData3 = line3 + IncomePercent + ",";  
      }
      else{//otherwise just add another 0
        newExpenseData3 = line3 + "0.0,";
      }


      if(line4.equals(parts4[0] + ",0.00,")){
        newExpenseData4 = parts4[0] + ",0.0,";
      }
      else{
        newExpenseData4 = line4 + "0.0,";
      }


      bufferedReader.close();

      FileWriter fileWriter = new FileWriter(filePath);
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

      //write the 5 lines back into the temp file with modified content
      bufferedWriter.write(newExpenseData1);
      bufferedWriter.newLine();
      bufferedWriter.write(newExpenseData2);
      bufferedWriter.newLine();
      bufferedWriter.write(newExpenseData3);
      bufferedWriter.newLine();
      bufferedWriter.write(newExpenseData4);//Spendings
      bufferedWriter.newLine();
      bufferedWriter.write(line5);

      bufferedWriter.close();
      
      System.out.println("");
      System.out.println("█▓▒▒░░░Expense Added!░░░▒▒▓█");

      expenseMenu();

      
      
    }//TRY END
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was
                           // thrown
      e.printStackTrace();

    } // CATCH END

    

    
  }

  public static void removeExpense(){
    try{
      
      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader
        
      String line1;
      String line2;
      String line3;
      String line4;
      String line5;
  
      String[] parts1 = null;// parts variables
      String[] parts2 = null;      
      String[] parts3 = null;
      String[] parts4 = null;
      String[] parts5 = null;
        
      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();
      line5 = bufferedReader.readLine();
    
      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");
      parts5 = line5.split(",");

  
      String expenseName = "";
      boolean isData = false;
      int expenseIndex = 0;
      String dataToRemove2 = "";
      String dataToRemove3 = "";
      String dataToImplement = "";
  
      System.out.println("");

    
      while(!isData){//TODO
          try{
            System.out.print("Enter Expense Name To Remove: ");
            expenseName = scanner.nextLine();
            for(int i = 0;i<parts2.length;i++){
              if(expenseName.equals(parts2[i])){
                expenseIndex = i;
                isData = true;
              }
              else{
              continue;
              }
            }
          }
          catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst expenses remove)");
            System.out.println("");
          }
        }

      int expenseIndexTruth = expenseIndex;
      expenseIndexTruth /= 2;
      expenseIndexTruth += 1;
      expenseIndex += 1;

      int incomeNum = Integer.parseInt(parts1[0]);
      String incomeRemovedPer = parts2[expenseIndex].replace("%", "");
      int incomeRemoved = Integer.parseInt(incomeRemovedPer);
      int newIncome = incomeNum + incomeRemoved;

      String newLine1 = Integer.toString(newIncome);
      
      dataToRemove2 = expenseName + "," + parts2[expenseIndex] + ",";
      
      String newLine2 = line2.replace(dataToRemove2, "");
      String newLine3 = "";
      String newLine4 = "";

      for(int i = 0;i<parts3.length;i++){
        if(i == expenseIndexTruth){
          continue;
        }
        else if(newLine3.equals("")){
          newLine3 = parts3[i] + ",";
        }
        else{
          newLine3 = newLine3 + parts3[i] + ",";
        }
      }

      for(int i = 0;i<parts4.length;i++){
        if(i == expenseIndexTruth){
          continue;
        }
        else if(newLine3.equals("")){
          newLine4 = parts4[i] + ",";
        }
        else{
          newLine4 = newLine4 + parts4[i] + ",";
        }
      }

      bufferedReader.close();

      FileWriter fileWriter = new FileWriter(filePath);
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

      //write the 5 lines back into the temp file with modified content
      bufferedWriter.write(newLine1);
      bufferedWriter.newLine();
      bufferedWriter.write(newLine2);
      bufferedWriter.newLine();
      bufferedWriter.write(newLine3);
      bufferedWriter.newLine();
      bufferedWriter.write(newLine4);
      bufferedWriter.newLine();
      bufferedWriter.write(line5);

      bufferedWriter.close();
      
      System.out.println("");
      System.out.println("▓▒▒░░░Expense Removed!░░░▒▒▓█");

      expenseMenu();

    
    }//TRY END
    catch (IOException e) {// In case of IOException this will provide where and why the Exception was
                           // thrown
      e.printStackTrace();

    }// CATCH END
    
  }//REMOVE EXPENSE END



  public static boolean isInteger(String str) {
    try {
        Integer.parseInt(str);
        return true; // The string is a valid integer
    } catch (NumberFormatException e) {
        return false; // The string is not a valid integer
    }
}//IS INTEGER END

  
}