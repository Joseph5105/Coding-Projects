import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DeleteBudgetPlan {

  static String bold = "\u001B[1m";
  static String reset = "\u001B[0m";
  static Scanner scanner = new Scanner(System.in);

  public static void helpDeleteMenu(){

    String option = "";
    while(!option.matches("1") || !option.matches("2")){
          try{
    
            System.out.println("");
            System.out.println("[1] Help");
            System.out.println("[2] Delete Budget Plan");
            System.out.println("[3] Main Menu");
            System.out.println("");
            System.out.print("Enter Option: ");
            option = scanner.nextLine();
            if(option.matches("1")){
              help();
              break;
            }
            else if(option.matches("2")){
              deletion();
              break;
            }
            else if(option.matches("3")){
              Main.menu();
              break;
            }
            else{
              continue;
            }
          }catch(NumberFormatException e){
            System.out.println("");
            System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀ (whilst menu)");
            System.out.println("");
          }
          
        }
  
    
    
  }//HELP DELETE MENU END

  public static void deletion() {

      String userConfirm = "";

      while(!userConfirm.matches("yes") || !userConfirm.matches("no")){
        try{
          System.out.println("");
          System.out.println("Are you sure you want to delete your entire budget plan?");
          System.out.print("Type (yes/no): ");
          userConfirm = scanner.nextLine();
          if(userConfirm.matches("no")){
            Main.menu();
          }
          else if(userConfirm.matches("yes")){
            break;
          }
          else{
            continue;
          }
        }catch(NumberFormatException e){
          System.out.println("");
          System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀");
          System.out.println("");
          System.out.print("Type (yes/no): ");
        }
        
      }
    
      // Step 1: Prepare your own data (sample data used here)
      List<String[]> newData = new ArrayList<>();
      newData.add(new String[]{"100"});
      newData.add(new String[]{"No Data","0%,"});
      newData.add(new String[]{"0","0.00,"});
      newData.add(new String[]{"0","0.00,"});
      newData.add(new String[]{"No Items,"});

      // Step 2: Replace the data in the CSV file
      String csvFilePath = "data.csv";
      replaceCsvData(csvFilePath, newData);
  }//DELETION END

  public static void replaceCsvData(String filePath, List<String[]> data) {
      try {
          // Create a new FileWriter instance to write to the CSV file
          FileWriter writer = new FileWriter(filePath);

          // Write the data to the CSV file
          for (String[] row : data) {
              for (int i = 0; i < row.length; i++) {
                  writer.append(row[i]);
                  if (i != row.length - 1) {
                      writer.append(",");
                  }
              }
              writer.append("\n");
          }

          // Close the writer
          writer.flush();
          writer.close();

          System.out.println("");
          System.out.println("█▓▒▒░░░Budget Data Removed!░░░▒▒▓█");
          Main.menu();
      } catch (IOException e) {
          e.printStackTrace();
          System.err.println("Error while replacing CSV data: " + e.getMessage());
      }
  }//REPLACE CSV DATA END

  public static void help(){

    System.out.println(bold + "HELP & INFORMATION" + reset);
    System.out.println("");
    System.out.println("");
    System.out.println(bold + "[1] View Budget:" + reset);
    System.out.println("Displays entire budget plan the user had recently updated within");
    System.out.println("their own monthly expenses, spendings, and income.");
    System.out.println("");
    System.out.println(bold + "[2] Edit Monthly Income:" + reset);
    System.out.println("Allows the user to edit their monthly income which will display into");
    System.out.println("their budget plan as their monthly balance and max spendings.");
    System.out.println(bold + "IT IS RECOMMENDED TO UPDATE THE MONTHLY INCOME BEFORE EXPENSES AND SPENDINGS," + reset);
    System.out.println("for this will allow the algorithm to update accurate data with accurate income.");
    System.out.println("");
    System.out.println(bold + "[3] Edit Monthly Expense:" + reset);
    System.out.println("Allows the user to add or remove their monthly expenses which will");
    System.out.println("display in their budget plan as the name of expense and the percentage");
    System.out.println("amount to spend at maximum.");
    System.out.println("");
    System.out.println(bold + "[4] Edit Spendings/View BB" + reset);
    System.out.println("Allows the user to add or remove any of their spendings they've made");
    System.out.println("within the real world. Spendings added into the budget plan");
    System.out.println("will allow the user to track how close their current spendings are");
    System.out.println("to the max amount they've set for themselves. Depending on");
    System.out.println("if the user had stayed within budget, the user will have a chance to gain");
    System.out.println("special items to use on BB the panda.");
    System.out.println("");
    System.out.println(bold + "[5] Help/Delete Budget" + reset);
    System.out.println("Allows the user to access this help information and");
    System.out.println("clear the entire budget plan in case the information becomes");
    System.out.println("inaccurate or if the user decides to start a new budget plan.");
    System.out.println("");
    System.out.println(bold + "[6] Quit App" + reset);
    System.out.println("");
    System.out.println("Exits the application.");
    System.out.println("");
    
    helpDeleteMenu();
    
    
  }//HELP END


  
}//DELETE BUDGET PLAN CLASS END
