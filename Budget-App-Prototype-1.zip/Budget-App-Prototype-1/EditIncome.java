import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EditIncome {
  public static void EditMonthlyIncome() {

    String filePath = "data.csv";// filePath stored from data file
    String bold = "\u001B[1m";
    String reset = "\u001B[0m";

    BufferedReader reader = null;
    String[] parts3 = null;
    boolean isInteger = false;

    try {// getting the current monthly income

      reader = new BufferedReader(new FileReader(filePath));

      String line1;
      String line2;
      String line3;

      line1 = reader.readLine();// Getting the first line and storing in a temp variable
      line2 = reader.readLine();
      line3 = reader.readLine();

      parts3 = line3.split(",");// splitting the line into parts by comma

      reader.close();

    }

    catch (IOException e) {
      e.printStackTrace();
    }

    String monthlyIncome = null;
    Scanner scanner = new Scanner(System.in);

    System.out.println("");
    System.out.println(bold + "Current Income: " + parts3[0] + reset);// current income
    System.out.println("");

    while (!isInteger) {// loop through if not an integer
      System.out.print("New Monthly Income: ");
      monthlyIncome = scanner.nextLine();

      try {// checks to see if input is an integer
        Integer.parseInt(monthlyIncome);
        isInteger = true; // If parsing succeeds, set isInteger to true to exit the loop
        // You can also use 'break;' to exit the loop instead of setting isInteger to
        // true
        // and keep the isInteger variable if needed for further processing.
      } catch (NumberFormatException e) {
        System.out.println("");
        System.out.println("▀▄▀▄▀▄NOT A VALID INPUT▄▀▄▀▄▀");
        System.out.println("");
      }

    }

    String searchString = parts3[0];// Change to be the first string in line 3
    String replacement = monthlyIncome;// Change to be the user's desired monthly income

    try {
      // Step 1: Open the file for reading
      reader = new BufferedReader(new FileReader(filePath));

      // Step 2: Read the content of the original file and store it in memory
      final List<String> lines = readFile(reader);

      // Step 3: Modify the content in memory to replace the desired string
      replaceString(lines, searchString, replacement);

      // Step 4: Write the updated content back to the file
      writeFile(filePath, lines);

      System.out.println("");
      System.out.println("█▓▒▒░░░Monthly Income Updated!░░░▒▒▓█");

      Main.menu();

    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      // Step 5: Close the file in the finally block to release resources
      if (reader != null) {
        try {
          reader.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }

  }

  private static List<String> readFile(BufferedReader reader) throws IOException {
    List<String> lines = new ArrayList<>();
    String line;
    while ((line = reader.readLine()) != null) {
      lines.add(line);
    }
    return lines;

  }

  private static void replaceString(List<String> lines, String searchString, String replacement) {
    for (int i = 0; i < lines.size(); i++) {
      String line = lines.get(i);
      int commaIndex = line.indexOf(",");
      if (commaIndex != -1) {
        String beforeComma = line.substring(0, commaIndex);
        String afterComma = line.substring(commaIndex);
        String updatedLine = beforeComma.replace(searchString, replacement) + afterComma;
        lines.set(i, updatedLine);
      }
    }
  }

  private static void writeFile(String filePath, List<String> lines) {
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(filePath));
      for (String line : lines) {
        writer.write(line);
        writer.newLine();
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      // Close the file in the finally block to release resources
      if (writer != null) {
        try {
          writer.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }

}
