import java.awt.geom.Line2D;
import java.io.BufferedReader;//Imported File Headers
import java.io.FileReader;
import java.io.IOException;

public class DisplayBudget {// class initializing
  public static void readBudget() {// void method initializing

    String bold = "\u001B[1m";
    String reset = "\u001B[0m";

    System.out.println("");
    System.out.println(bold + "╔══╗     ╔╗     ╔╗");
    System.out.println(bold + "║╔╗║     ║║    ╔╝╚╗");
    System.out.println(bold + "║╚╝╚╦╗╔╦═╝╠══╦═╩╗╔╝");
    System.out.println(bold + "║╔═╗║║║║╔╗║╔╗║ ═╣║");
    System.out.println(bold + "║╚═╝║╚╝║╚╝║╚╝║ ═╣╚╗");
    System.out.println(bold + "╚═══╩══╩══╩═╗╠══╩═╝");
    System.out.println(bold + "          ╔═╝║");
    System.out.println(bold + "          ╚══╝" + reset);

    try {

      String filePath = "data.csv";// Storing File Path
      FileReader fileReader = new FileReader(filePath);// Initializing File Reader
      BufferedReader bufferedReader = new BufferedReader(fileReader);// Initializing File Buffered Reader

      String line1;// Initializing Line1 Variable (The Amount of Percetage Left to Add to Budget)
      String line2;// Initializing Line2 Variable (All Expenses & Percentages)
      String line3;// Initializing Line3 Variable (Monthly Income & Amount that should be spent on
                   // each expense)
      String line4;// Initializing Line4 Variable (Current Spending Total & Amount that has been
                   // spent on each expense)

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Storing the second line into the line varible
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();// Storing the forth line into the line variable

      String[] parts1 = null;// parts variables
      String[] parts2 = null;
      String[] parts3 = null;
      String[] parts4 = null;
      int j = 1;// second index

      String[] partsNum2 = line2.split(",");// Splitting the line2 into parts whenever there is a comma to separate
      String[] partsNum3 = line3.split(",");
      String[] partsNum4 = line4.split(",");
      int numStrings2 = partsNum2.length;// Initializing numStrings2 to be the amount of strings in each line
      int twoDivider = 1;// Initializing a divider to print in order

      bufferedReader.close();// Closes BufferedReader
      fileReader.close();// Closes FileReader

      fileReader = new FileReader(filePath);// Opens new fileReader
      bufferedReader = new BufferedReader(fileReader);// Opens new bufferedReader

      line1 = bufferedReader.readLine();// Getting the first line and storing in a temp variable
      line2 = bufferedReader.readLine();// Sets line to be the second line
      line3 = bufferedReader.readLine();// Storing the third line into the line variable
      line4 = bufferedReader.readLine();// Storing the forth line into the line varible

      parts1 = line1.split(" ");// spliting each string by commas into the string array
      parts2 = line2.split(",");// spliting each string by commas into the string array
      parts3 = line3.split(",");// splitting each string by commas into the string array
      parts4 = line4.split(",");// splitting each string by commas into the string array

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁MAX SPENDINGS▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + "Monthly Income: " + parts3[0] + "$" + reset);
      System.out.println("");

      for (int i = 0; i < numStrings2; i += 2) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line
        System.out.print(parts3[j] + "$");// prints the j string of the line
        System.out.println("");

        j++;

      } // FOR END

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁CURRENT SPENDINGS▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + "Monthly Balance: " + parts4[0] + "$" + reset);
      System.out.println("");

      j = 1;// reset second index

      for (int i = 0; i < numStrings2; i += 2) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line
        System.out.print(parts4[j] + "$");// prints the j string of the line
        System.out.println("");

        j++;

      }// FOR END

      System.out.println("");
      System.out.println("✩░▒▓▆▅▃▂▁EXPENSES▁▂▃▅▆▓▒░✩");
      System.out.println("");
      System.out.println(bold + "Monthly Expense: " + parts1[0] + "%/100%" + reset);
      System.out.println("");

      for (int i = 0; i < numStrings2; i++) {// For loop in each line depending on the amount of strings

        System.out.print(parts2[i] + "   ");// prints the i string of the line

        if (twoDivider % 2 == 0) {// if the divider is even then a new line will separate the next amount of
                                  // strings
          System.out.println("");
        }

        twoDivider++;// updates the divider

      } // FOR END

      bufferedReader.close();// Closes BufferedReader
      fileReader.close();// Closes FileReader

    } // TRY END

    catch (IOException e) {// In case of IOException this will provide where and why the Exception was
                           // thrown

      e.printStackTrace();

    } // CATCH END

    for (int i = 0; i < 5; i++) {
      System.out.println("");
    }

    Main.menu();

  }

  public static boolean isInteger(String str) {
    try {
      Integer.parseInt(str);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

}